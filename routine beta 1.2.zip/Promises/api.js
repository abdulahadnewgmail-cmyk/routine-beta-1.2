/*
curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent" \
  -H 'Content-Type: application/json' \
  -H 'X-goog-api-key: AIzaSyCnyBOAR4hbiUC58oqeEIr-FRSIlG7OxtE' \
  -X POST \
  -d '{
    "contents": [
      {
        "parts": [
          {
            "text": "Explain how AI works in a few words"
          }
        ]
      }
    ]
  }'

*/
let res, data;
async function get(prompt) {
  res = await fetch(
    "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent",
    {
      method: 'POST',
      headers:{
        'Content-Type': 'application/json',
        'X-goog-api-key': 'AIzaSyCnyBOAR4hbiUC58oqeEIr-FRSIlG7OxtE'
      },
      body:JSON.stringify({
        "contents": [
      {
        "parts": [
          {
            'text': prompt
          }
        ]
      }
    ]
      })
      
    }
  )
  data = await res.json()
  console.log(data)
}
get('What is 1+2')